Readme.txt for BSP for NXP LPC2378
Supported hardware:
===================
The sample project for NXP LPC2378 is prepared
to run on a Keil MCB2300 eval board,
but may be used on other target hardware as well.

Configurations
==============
- RAM:
  This configuration is prepared for download into 
  internal RAM using J-Link and GDB.
  A call of LPC2xxx_RAM_JLink.gdb ensures 
  that the first 64 bytes at 0x00 are mapped 
  to internal RAM.

- FLASH:
  This configuration is prepared for debugging and
  can be downloaded into internal FLASH using 
  the J-Link FlashDL feature.
  The J-Link features FlashDL and FlashBPs are
  enabled by default.
  A call of LPC2xxx_FLASH_JLink.gdb ensures 
  that the first 64 bytes at 0x00 are mapped 
  to FLASH.
