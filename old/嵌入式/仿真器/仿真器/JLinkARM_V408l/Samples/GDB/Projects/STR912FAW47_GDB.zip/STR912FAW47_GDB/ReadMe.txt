Readme.txt for BSP for STR912

Supported hardware:
===================
The sample project for STR912 CPU is prepared for
ST STR912 Eval boards.

Tested with: IAR KS STR912-SK Rev. A

Configurations
==============
- FLASH:
  This configuration is prepared for debugging and
  can be downloaded into internal FLASH using the
  J-Link GDB Server.
